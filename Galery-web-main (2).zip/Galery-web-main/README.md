# Memoweb
Ini adalah web untuk kenangan sekolah atau apapun dibuat dengan NextJS

# Display
### Light
![Display Light](light.png)

### Dark
![Display Dark](dark.png)
